<?php
session_start();
include("includes/config.php");

if (isset($_POST['submit'])) {
    $regno = $_POST['regno'];

    $query = mysqli_query($con, "SELECT * FROM students WHERE StudentRegno='$regno'");
    $num = mysqli_fetch_array($query);

    if ($num > 0) {
        $reset_token = md5(uniqid(rand(), true));

        // Set the reset token and expiry time in the database
        $update_query = mysqli_query($con, "UPDATE students SET reset_token='$reset_token', reset_token_expiry=DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE StudentRegno='$regno'");

        if ($update_query) {
            // Send an email with a link to reset password
            // You can use a library like PHPMailer for sending emails

            $reset_link = "http://yourwebsite.com/reset-password.php?token=$reset_token";
            $to = $num['email'];
            $subject = "Password Reset";
            $message = "Click on the following link to reset your password: $reset_link";

            // Uncomment the following lines and replace placeholders with actual values to send an email
            // mail($to, $subject, $message);

            $_SESSION['successmsg'] = "Password reset link has been sent to your email.";
        } else {
            $_SESSION['errmsg'] = "Error occurred while generating reset token";
        }
    } else {
        $_SESSION['errmsg'] = "Invalid Registration Number";
    }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title>Forgot Password</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
    <?php include('includes/header.php');?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="page-head-line">Forgot Password</h4>
                </div>
            </div>
            <span style="color:red;" ><?php echo htmlentities($_SESSION['errmsg']); ?><?php echo htmlentities($_SESSION['errmsg']="");?></span>
            <span style="color:green;" ><?php echo htmlentities($_SESSION['successmsg']); ?><?php echo htmlentities($_SESSION['successmsg']="");?></span>
            <form name="ForgotPassword" method="post">
                <div class="row">
                    <div class="col-md-6">
                        <label>Enter Reg no : </label>
                        <input type="text" name="regno" class="form-control" required />
                        <hr />
                        <button type="submit" name="submit" class="btn btn-info">
                            <span class="glyphicon glyphicon-envelope"></span> &nbsp;Send Reset Link
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>

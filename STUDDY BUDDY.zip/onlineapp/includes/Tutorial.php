<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Developer</title>

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Noto+Serif&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" type="text/css" href="developer.css" />
  </head>
  <body>
  
    <div class="container">
      <!--header section start-->

      <div>
        <header>
		  <img class="logo" src="image/sselogo.png" />
          <h1 style = "color:#f6Af1a;">SAVEETHA SCHOOL OF ENGINEERING</h1>
          
        </header>
      </div>

      <!--header section start-->
      <hr />
	  
	 

      <main>
        <div>
          <img class="banner" src="image/top11.png" />

          <p class="fast-para">
            If you are looking to learn web development online, there are more
            than enough resources out there to teach you everything you need to
            know. In fact, many (if not most) of the web developers in the world
            today have launched successful careers by learning web development
            online from scratch. But even the most ambitious self-starters run
            into the problem of deciding where to begin. Below you will find our
            picks for the top 10 websites to help you learn web development
            online
          </p>
          <br />
          <h2 class="fast-para">Why Learn Web Development Online</h2>
          <p class="fast-para">
            As a web developer, your credibility is more about the strength of
            your portfolio than it is about your credentials. Your employment
            opportunities will often come from concrete skills and samples of
            your work rather than a degree from a university. It’s not that a
            proper college education isn’t important or valuable as a web
            developer. Rather, it’s to say that if attending a university isn’t
            in the cards, you can learn everything you need to know about web
            development online. The web development industry continues to grow
            exponentially so you won’t find a shortage of resources. The most
            important thing to do is start.
          </p>
          <br />

          <h3>
            Great YouTube channel to help you learn web development online
          </h3>
          <div align="center">
          <iframe width="800" height="500" src="https://www.youtube.com/embed/zZ6vybT1HQs?si=fxTStxSKxBp7LgeF" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
          </div>
          <br />
          <br />
          <br />

          <h2 class="hyperlink">More Places to Learn Web Development</h2>
          <p class="hyperlink">
            It is extremely difficult to narrow this list to only 10, so here
            are a some more resources for you to check out.
          </p>

          <ul>
            <li>
              <a
                href="https://www.edx.org/learn/front-end-web-development"
                target="black"
                >edx.org</a
              >
            </li>
            <li>
              <a href="https://www.khanacademy.org/" target="black"
                >Khan Academy</a
              >
              &nbsp; (free)
            </li>
            <li>
              <a href="https://www.freecodecamp.org/" target="black"
                >freecodecamp.org
              </a>
              &nbsp;(Free)
            </li>
            <li>
              <a href="https://www.w3schools.com/" target="black"
                >W3schools.com</a
              >
              &nbsp;(Free)
            </li>
            <li>
              <a href="http://tympanus.net/codrops/" target="black">Codrops</a>
              &nbsp;(Free)
            </li>
            <li>
              <a href="https://developers.google.com/web/" target="black"
                >developers.google.com/web</a
              >
              &nbsp;(Free)
            </li>
          </ul>
          <br />

          <h4 class="last">Final Thoughts</h4>
          <p class="last">
            When it comes to starting a career in web development, getting
            started can be the hardest part. But once you do, you might be
            surprised at just how much you can learn in just a single day with
            the online resources available. Then it is just a matter of
            mastering your skills toward your new career. Hopefully, these web
            developer resources can help you along the way
          </p>
          <br />
          <p class="last">
            Feel free to share some of your favorite online resources in the
            comments below
          </p>

          <p class="last">Cheers!</p>
        </div>
      </main>

      <hr />
    </div>

    <footer>
      <b> Copyright&copy;2021 </b>
    </footer>
  </body>
</html>

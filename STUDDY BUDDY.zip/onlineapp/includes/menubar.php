<section class="menu-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar-collapse collapse ">
                    <ul id="menu-top" class="nav navbar-nav navbar-right">
                    <li><a href="page2.php">Home</a></li>
                        <li><a href="pincode-verification.php">Enroll for Course</a></li>
                        <li><a href="coursedisplay.php">Tutorial</a></li>
                        <li><a href="MockTest.php">Mock Test</a></li>
                        <li><a href="Query.php">Query</a></li>
                        <li><a href="enroll-history.php">Enroll History</a></li>
                        <li><a href="Meet.php">Live Meet</a></li>
                        <li><a href="my-profile.php">My Profile</a></li>
                        <li><a href="scoreboard.php">Scoreboard</a></li>
                        <li><a href="change-password.php">Change Password</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

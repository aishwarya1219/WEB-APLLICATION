<?php
session_start();
include('includes/config.php');
error_reporting(0);
if(strlen($_SESSION['login']) == 0) {
    header('location:index.php');
}  
else 
    if (isset($_GET['del'])) {
        $id = intval($_GET['id']);

        // Check if there are associated PDFs
        $checkPDF = mysqli_query($con, "SELECT COUNT(*) as pdfCount FROM pdfs WHERE courseID='$id'");
        $pdfCountResult = mysqli_fetch_assoc($checkPDF);
        $pdfCount = $pdfCountResult['pdfCount'];

    if (isset($_POST['submit'])) {
        // Course Information Fields
        $coursecode = isset($_POST['coursecode']) ? $_POST['coursecode'] : '';
        $coursename = isset($_POST['coursename']) ? $_POST['coursename'] : '';
        $courseunit = isset($_POST['courseunit']) ? $_POST['courseunit'] : '';
        $seatlimit =  isset($_POST['seatlimit']) ? $_POST['seatlimit'] : '';

        // Validate and insert course data into the database
        if (!empty($coursecode) && !empty($coursename) && !empty($courseunit) && !empty($seatlimit)) {
            $ret = mysqli_query($con, "INSERT INTO course(courseCode, courseName, courseUnit, noofSeats) VALUES('$coursecode','$coursename','$courseunit','$seatlimit')");

            if ($ret) {
                $_SESSION['msg'] = "Course Created Successfully !!";
            } else {
                $_SESSION['msg'] = "Error: Course not created";
            }
        } else {
            $_SESSION['msg'] = "Error: Please fill all the Course Information fields";
        }

        // PDF Information Fields
        $pdfName = isset($_POST['pdf_name']) ? $_POST['pdf_name'] : '';
        if (isset($_FILES['pdf_file']) && isset($_FILES['pdf_file']['name'])) {
            $pdfPath = "pdfs/" . basename($_FILES["pdf_file"]["name"]);
            move_uploaded_file($_FILES["pdf_file"]["tmp_name"], $pdfPath);

            // Validate and insert PDF data into the database
            if (!empty($pdfName) && !empty($pdfPath)) {
                $courseID = mysqli_insert_id($con); // Get the last inserted course ID

                $ret = mysqli_query($con, "INSERT INTO pdfs(courseID, pdf_name, pdf_path, creationDate) VALUES ('$courseID', '$pdfName', '$pdfPath', NOW())");

                if ($ret) {
                    $_SESSION['pdf_msg'] = "PDF Added Successfully !!";
                } else {
                    $_SESSION['pdf_msg'] = "Error: PDF not added";
                }
            } else {
                $_SESSION['pdf_msg'] = "Error: Please fill all the PDF Information fields";
            }
        } else {
            // Handle the case when pdf_file is not set
            $_SESSION['pdf_msg'] = "Error: PDF File not provided";
        }

        // Redirect to prevent form resubmission
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Course PDF</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/header.php');?>
    <!-- LOGO HEADER END-->
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');
}
 ?>
 <br><br>
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Manage Course
            </div>
            <div class="panel-body">
                <div class="table-responsive table-bordered">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Course Unit</th>
                                <th>Seat limit</th>
                                <th>Creation Date</th>
                                <th>PDF Name</th>
                                <th>PDF File</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            $userRegNo = $_SESSION['login'];
                            $sql = mysqli_query($con, "SELECT course.*, pdfs.pdf_name AS pdf_name, pdfs.pdf_path AS pdf_path FROM courseenrolls 
                                JOIN course ON course.id = courseenrolls.course 
                                LEFT JOIN pdfs ON course.id = pdfs.courseID 
                                WHERE courseenrolls.studentRegno='$userRegNo'");
                            $cnt = 1;
                            while ($row = mysqli_fetch_array($sql)) {
                            ?>
                                <tr>
                                    <td><?php echo $cnt; ?></td>
                                    <td><?php echo htmlentities($row['courseCode']); ?></td>
                                    <td><?php echo htmlentities($row['courseName']); ?></td>
                                    <td><?php echo htmlentities($row['courseUnit']); ?></td>
                                    <td><?php echo htmlentities($row['noofSeats']); ?></td>
                                    <td><?php echo htmlentities($row['creationDate']); ?></td>
                                    <td><?php echo htmlentities($row['pdf_name']); ?></td>
                                    <td>
                                        <?php
                                        if (!empty($row['pdf_path'])) {
                                        ?>
                                            <a href="<?php echo htmlentities($row['pdf_path']); ?>" target="_blank">Download PDF</a>
                                        <?php
                                        } else {
                                            echo "No PDF available";
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php
                                $cnt++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    
    <!-- CONTENT-WRAPPER SECTION END-->
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>

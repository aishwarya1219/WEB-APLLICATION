<section class="menu-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar-collapse collapse ">
                    <ul id="menu-top" class="nav navbar-nav navbar-right">
                    <li><a href="page1.php">Home</a></li>
                        <li><a href="home.php">Enroll for Course</a></li>
                        <li><a href="login.php">Tutorial</a></li>
                        <li><a href="home.php">Mock Test</a></li>
                        <li><a href="home.php">Query</a></li>
                        <li><a href="home.php">Enroll History</a></li>
                        <li><a href="home.php">Live Meet</a></li>
                        <li><a href="home.php">My Profile</a></li>
                        <li><a href="home.php">Scoreboard</a></li>
                        <li><a href="home.php">Change Password</a></li>
                        <li><a href="home.php">Login</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

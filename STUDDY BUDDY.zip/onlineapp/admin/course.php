<?php
session_start();
include('includes/config.php');

if (strlen($_SESSION['alogin']) == 0) {
    header('location:index.php');
    exit();
} else {
    if (isset($_GET['del'])) {
        $id = intval($_GET['id']);

        // Check if there are associated PDFs
        $checkPDF = mysqli_query($con, "SELECT COUNT(*) as pdfCount FROM pdfs WHERE courseID='$id'");
        $pdfCountResult = mysqli_fetch_assoc($checkPDF);
        $pdfCount = $pdfCountResult['pdfCount'];

        if ($pdfCount > 0) {
            // If there are associated PDFs, delete them first
            $delPDF = mysqli_query($con, "DELETE FROM pdfs WHERE courseID='$id'");

            if ($delPDF) {
                // Now, delete the course
                $delCourse = mysqli_query($con, "DELETE FROM course WHERE id='$id'");

                if ($delCourse) {
                    $_SESSION['delmsg'] = "Course and associated PDFs deleted successfully";
                } else {
                    $_SESSION['delmsg'] = "Error: Unable to delete course";
                    $_SESSION['delmsg'] .= "<br>" . mysqli_error($con);
                }
            } else {
                $_SESSION['delmsg'] = "Error: Unable to delete associated PDFs";
                $_SESSION['delmsg'] .= "<br>" . mysqli_error($con);
            }
        } else {
            // If there are no associated PDFs, delete the course directly
            $delCourse = mysqli_query($con, "DELETE FROM course WHERE id='$id'");

            if ($delCourse) {
                $_SESSION['delmsg'] = "Course deleted successfully";
            } else {
                $_SESSION['delmsg'] = "Error: Unable to delete course";
                $_SESSION['delmsg'] .= "<br>" . mysqli_error($con);
            }
        }
    }


    if (isset($_POST['submit'])) {
        // Course Information Fields
        $coursecode = isset($_POST['coursecode']) ? $_POST['coursecode'] : '';
        $coursename = isset($_POST['coursename']) ? $_POST['coursename'] : '';
        $courseunit = isset($_POST['courseunit']) ? $_POST['courseunit'] : '';
        $seatlimit =  isset($_POST['seatlimit']) ? $_POST['seatlimit'] : '';

        // Validate and insert course data into the database
        if (!empty($coursecode) && !empty($coursename) && !empty($courseunit) && !empty($seatlimit)) {
            $ret = mysqli_query($con, "INSERT INTO course(courseCode, courseName, courseUnit, noofSeats) VALUES('$coursecode','$coursename','$courseunit','$seatlimit')");

            if ($ret) {
                $_SESSION['msg'] = "Course Created Successfully !!";
            } else {
                $_SESSION['msg'] = "Error: Course not created";
            }
        } else {
            $_SESSION['msg'] = "Error: Please fill all the Course Information fields";
        }

        // PDF Information Fields
        $pdfName = isset($_POST['pdf_name']) ? $_POST['pdf_name'] : '';
        if (isset($_FILES['pdf_file']) && isset($_FILES['pdf_file']['name'])) {
            $pdfPath = "pdfs/" . basename($_FILES["pdf_file"]["name"]);
            move_uploaded_file($_FILES["pdf_file"]["tmp_name"], $pdfPath);

            // Validate and insert PDF data into the database
            if (!empty($pdfName) && !empty($pdfPath)) {
                $courseID = mysqli_insert_id($con); // Get the last inserted course ID

                $ret = mysqli_query($con, "INSERT INTO pdfs(courseID, pdf_name, pdf_path, creationDate) VALUES ('$courseID', '$pdfName', '$pdfPath', NOW())");

                if ($ret) {
                    $_SESSION['pdf_msg'] = "PDF Added Successfully !!";
                } else {
                    $_SESSION['pdf_msg'] = "Error: PDF not added";
                }
            } else {
                $_SESSION['pdf_msg'] = "Error: Please fill all the PDF Information fields";
            }
        } else {
            // Handle the case when pdf_file is not set
            $_SESSION['pdf_msg'] = "Error: PDF File not provided";
        }

        // Redirect to prevent form resubmission
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Admin | Upload PDF</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
    <?php include('includes/header.php');?>

    <?php if ($_SESSION['alogin'] != "") {
        include('includes/menubar.php');
    } ?>
   
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-head-line"> Course Details</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Course Details
                        </div>
                        <div>
                            <font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?></font>
                            <div class="panel-body">
                                <form name="combinedForm" method="post" enctype="multipart/form-data">
    
                                    <!-- Course Information Fields -->
                                    <div class="form-group">
                                        <label for="coursecode">Course Code:</label>
                                        <input type="text" class="form-control" id="coursecode" name="coursecode" placeholder="Course Code" required />
                                    </div>
    
                                    <div class="form-group">
                                        <label for="coursename">Course Name:</label>
                                        <input type="text" class="form-control" id="coursename" name="coursename" placeholder="Course Name" required />
                                    </div>
    
                                    <div class="form-group">
                                        <label for="courseunit">Course Unit:</label>
                                        <input type="text" class="form-control" id="courseunit" name="courseunit" placeholder="Course Unit" required />
                                    </div> 

                                    <div class="form-group">
                                        <label for="seatlimit"> seatlimit:</label>
                                        <input type="text" class="form-control" id="seatlimit" name="seatlimit" placeholder="seatlimit" required />
                                    </div> 
    
                                    <!-- PDF Information Fields -->
                                    <div class="form-group">
                                        <label for="pdf_name">PDF Name:</label>
                                        <input type="text" name="pdf_name" required />
                                    </div>
    
                                    <div class="form-group">
                                        <label for="pdf_file">Select PDF:</label>
                                        <input type="file" name="pdf_file" required />
                                    </div>
    
                                    <center>
                                        <button type="submit" name="submit" class="btn btn-default">Submit</button>
                                    </center>
    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <font color="red" align="center"><?php echo htmlentities($_SESSION['delmsg']);?><?php echo htmlentities($_SESSION['delmsg']="");?></font>
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Manage Course
            </div>
            <div class="panel-body">
                <div class="table-responsive table-bordered">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Course Unit</th>
                                <th>Seat limit</th>
                                <th>Creation Date</th>
                                <th>PDF Name</th>
                                <th>PDF File</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = mysqli_query($con, "SELECT course.*, pdfs.pdf_name AS pdf_name, pdfs.pdf_path AS pdf_path FROM course LEFT JOIN pdfs ON course.id = pdfs.courseID");
                            $cnt = 1;
                            while ($row = mysqli_fetch_array($sql)) {
                            ?>
                                <tr>
                                    <td><?php echo $cnt; ?></td>
                                    <td><?php echo htmlentities($row['courseCode']); ?></td>
                                    <td><?php echo htmlentities($row['courseName']); ?></td>
                                    <td><?php echo htmlentities($row['courseUnit']); ?></td>
                                    <td><?php echo htmlentities($row['noofSeats']); ?></td>
                                    <td><?php echo htmlentities($row['creationDate']); ?></td>
                                    <td><?php echo htmlentities($row['pdf_name']); ?></td>
                                    <td>
                                        <?php
                                        if (!empty($row['pdf_path'])) {
                                        ?>
                                            <a href="<?php echo htmlentities($row['pdf_path']); ?>" target="_blank">Download PDF</a>
                                        <?php
                                        } else {
                                            echo "No PDF available";
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <a href="edit-course.php?id=<?php echo $row['id'] ?>">
                                            <button class="btn btn-primary"><i class="fa fa-edit "></i> Edit</button>
                                        </a>
                                        <a href="upload-pdf.php?id=<?php echo $row['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete?')">
                                            <button class="btn btn-danger">Delete</button>
                                        </a>
                                    </td>
                                </tr>
                            <?php
                                $cnt++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <script>
    <?php
    if (!empty($_SESSION['pdf_msg'])) {
        echo "alert('" . htmlentities($_SESSION['pdf_msg']) . "');";
        // Clear the session variable after displaying the alert
        $_SESSION['pdf_msg'] = "";
    }
    ?>
</script>

    <!-- CONTENT-WRAPPER SECTION END-->
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
<?php
// Clear session messages after displaying
$_SESSION['msg'] = "";
$_SESSION['delmsg'] = "";
?>

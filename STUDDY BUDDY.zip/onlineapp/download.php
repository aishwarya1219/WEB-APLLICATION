<?php
if (isset($_GET['pdf'])) {
    $pdfPath = urldecode($_GET['pdf']);
    $fullPath = __DIR__ . '/' . $pdfPath;

    if (file_exists($fullPath)) {
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . basename($pdfPath) . '"');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($fullPath));
        header('Accept-Ranges: bytes');

        readfile($fullPath);
        exit;
    } else {
        echo "File not found: " . $pdfPath;
    }
} else {
    echo "PDF path not provided.";
}
?>

<?php
     
 $data = [ 
         'user_id' => '1',
         'payment_id' => $_POST['razorpay_payment_id'],
         'amount' => $_POST['totalAmount'],
         'product_id' => $_POST['product_id'],
        ];
 
 // you can write your database insertation code here
 // after successfully insert transaction in database, pass the response accordingly


 
        $db_host        = "localhost";
        $db_username    = "root";
        $db_password    = "";
        $db_name        = "onlinecourse2";

        $conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);

        if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        }


        $RecordArray = array();
        $RecordArray["user_id"]            = $_POST['id'];
        $RecordArray["course_id"]         = $_POST['product_id'];
        $RecordArray["payment_id"]    = $_POST['razorpay_payment_id'];
           
        $columns = implode(", ",array_keys($RecordArray));
        $escaped_values = array_map(array($conn, 'real_escape_string'), array_values($RecordArray));
        $values  = implode("', '", $escaped_values);
        $Query = "INSERT INTO tbl_records ($columns) VALUES ('$values')";
        $Execute = mysqli_query($conn,$Query) or die ("Error in query: $Query. ".mysqli_error($conn));



 $arr = array('rid'=> mysqli_insert_id($conn),'msg' => 'Payment successfully credited', 'status' => true);  
 
 echo json_encode($arr);
 
?>
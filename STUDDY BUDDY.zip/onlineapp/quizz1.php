<?php
session_start();
include('includes/config.php');
error_reporting(0);
if(strlen($_SESSION['login']) == 0) 
{
    header('location:index.php');
} else 
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Archivo+Narrow&display=swap" rel="stylesheet">

</head>
<style>
body
{
    background: #d6d6d6;
}
.app{
    background: #fff;
    width: 90%;
    max-width: 600px;
    margin: 50px auto 0;
    border-radius: 10px;
    padding: 30px;
}
.quiz h2{
    font-size: 18px;
     color: #222;
     font-weight: 600;
}
.btn{
    background: #fff;
    color: #222;
    font-weight: 500;
    width: 100%;
    border: 1px solid #222;
    padding: 10px;
    margin: 10px 0;   
    text-align: left;
    border-radius: 4px;
    cursor: pointer;
}
#next-btn{
    background: #3ea3b3;
    color: #fff;
    font-weight: 500;
    width: 150px;
    border: 0;
    padding: 10px;
    margin: 20px auto 0;
    border-radius: 4px;
    cursor: pointer;
    display: none;
}
.correct{
    background: #9aeabc;
}
.incorrect{
    background: #ff9393;
} 
.custom-btn {
    background:#3ea3b3;
    color: #fff;
    font-weight: 500;
    width: 150px;
    border: 0;
    padding: 10px;
    margin: 20px auto 0;
    border-radius: 4px;
    cursor: pointer;
}

</style>
<body>
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');
}
?>
  <div class="app">
    <center><h1>QUIZ</h1></center>
    <div class="quiz">
      <h2 id="question">Question goes here</h2>
      <div id="answer-buttons">
        <button class="btn">Answer 1</button>
        <button class="btn">Answer 2</button>
        <button class="btn">Answer 3</button>
        <button class="btn">Answer 4</button>
      </div>
      <button id="next-btn">Next</button>
      <input type="hidden" id="stuname" value="<?php echo $_SESSION['sname']; ?>" >
      <input type="hidden" id="stucourse" value="<?php echo $_GET['course']; ?>" >

      <button id="submit-btn" class="custom-btn">Submit</button>
      <button id="certificate" class="custom-btn" > Download Certificate</button>

      <!-- <button id="playagain-btn" class="custom-btn"> Download Certificate</button> -->
      
    </div>
  </div>
  <Script>
const questions = [
    {
        question:"What is the output of the following code : print 9//2",
        
        answer: [
            { text:"Error", correct: false},
            { text:"4.5", correct: false},
            { text:"4.0", correct: false},
            { text:"4", correct: true},
        ]
    },
    {
        question: "Which function overloads the >> operator?",
       answer: [
           { text:"more()", correct: false},
           { text:"gt()", correct: false},
           { text:"ge()", correct: false},
           { text:"none of these", correct: true},
       ] 
    },
    {
        question: "Which operator is overloaded by the or() function?",
       answer: [
           { text:"//", correct: false},
           { text:"||", correct: false},
           { text:"\\", correct: false},
           { text:"/", correct:true},
       ] 
    },
    {
        question: "What is the output of the expression : 3*1**3?",
       answer: [
           { text:"27", correct: false},
           { text:"9", correct: false},
           { text:"3", correct: true},
           { text:"1", correct: false},
       ] 
    },
    {
        question: "_____ is used to find and fix bugs in the python programs.",
       answer: [
           { text:"Dynamic", correct: false},
           { text:"JRE", correct: false},
           { text:"JDK", correct: false},
           { text:"Debugging", correct: true},
       ] 
    },
    {
        question: " Who invented python Programming?",
       answer: [
           { text:"Guido van Rossum", correct: true},
           { text:"James Gosling", correct: false},
           { text:"Dennis Ritchie", correct: false},
           { text:"Bjarne Stroustrup", correct: false},
       ] 
    },
    {
        question: " Which environment variable is used to set the PYTHON path?",
       answer: [
           { text:"MAVEN_Path", correct: false},
           { text:"PATH", correct: false},
           { text:"pythonpath", correct: false},
           { text:"PYTHONPATH", correct: true},
       ] 
    },
    {
        question: " Which type of programming does python Support?",
       answer: [
           { text:"Object-oriented", correct: false},
           { text:"Structured programming", correct: false},
           { text:"functional programming", correct: false},
           { text:"all of the mentioned", correct: true},
       ] 
    },
    {
        question: " Is Python case sensitive when dealing with identifiers?",
       answer: [
           { text:"no", correct: false},
           { text:"Yes", correct: true},
           { text:"keyword dependent", correct: false},
           { text:"none of the mentioned", correct: false},
       ] 
    },
    {
        question: " What is the extension of python code files?",
       answer: [
           { text:".js", correct: false},
           { text:".txt", correct: false},
           { text:".class", correct: false},
           { text:".py", correct: true},
       ] 
    },
];

const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");
const submitButton = document.getElementById("submit-btn");
const playAgainButton = document.getElementById("certificate");

let currentQuestionIndex = 0;
let score = 0;

function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    submitButton.style.display = "none"; // Hide the Submit button
    playAgainButton.style.display = "none"; // Hide the Play Again button
    showQuestion();
}

function showQuestion() {
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question; // Remove the extra period after currentQuestion.question

    currentQuestion.answer.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
        if (answer.correct) {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
    });
}



function resetState(){
    nextButton.style.display = "none";
    while(answerButtons.firstChild){
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function selectAnswer(e){
    const selectedBtn = e.target;
    const iscorrect = selectedBtn.dataset.correct === "true";
    if(iscorrect){
        selectedBtn.classList.add("correct");
        score++;
    }else{
        selectedBtn.classList.add("incorrect");
    }
    Array.from(answerButtons.children).forEach(button => {
        if(button.dataset.correct === "true"){
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    nextButton.style.display = "block";
}

function showScore() {
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${questions.length}!`; // Corrected template literal
    nextButton.style.display = "none"; // Hide the Next button
    submitButton.style.display = "block"; // Show the Submit button
    playAgainButton.style.display = "block"; // Show the Play Again button
}


function   handelNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length){
        showQuestion();
    }else{
        showScore();
    }
}


nextButton.addEventListener("click", ()=>{
    if(currentQuestionIndex < questions.length){
        handelNextButton();
    }else{
        startQuiz()
    }
});
submitButton.addEventListener("click", () => {
    // Handle the submission of the score here
    // You can use AJAX or fetch to send the score to your server
    // For now, let's just display a message
    alert(`Total Score: ${score}`);
});

submitButton.addEventListener("click", () => {
    // Send the score to the PHP script
    fetch('submit-score.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `score=${score}`,
    })
    .then(response => {
        if (response.ok) {
            // Score submitted successfully
            alert("Successfully Submitted");
        } else {
            // Handle error
            console.error('Error submitting score');
        }
    })
    .catch(error => {
        console.error('Network error:', error);
    });
});

// playAgainButton.addEventListener("click", () => {
//     startQuiz();
// });

startQuiz();
</Script>
  
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <script src="https://unpkg.com/pdf-lib/dist/pdf-lib.min.js"></script>
    <script src="https://unpkg.com/@pdf-lib/fontkit@0.0.4"></script>
    <script src="assets/js/certificate.js"></script>
    <script src="assets/js/filesaver.js"></script>

</body>
</html>

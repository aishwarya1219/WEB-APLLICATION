<?php
    session_start();

    $score = $_REQUEST["score"];
    if (isset($_SESSION['sname'])) 
    {
        $studentName   = $_SESSION['sname'];
        $studentRegID  = $_SESSION["id"];




        $db_host        = "localhost";
        $db_username    = "root";
        $db_password    = "";
        $db_name        = "onlinecourse2";

        $conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $update_query = "UPDATE students SET score = $score WHERE StudentRegno = $studentRegID";
        

        if (mysqli_query($conn, $update_query)) 
        {
            echo "Score updated successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
          
        mysqli_close($conn);

        // $db_connection = new mysqli($db_host, $db_username, $db_password, $db_name);

        // if ($db_connection->connect_error) {
        //     die("Connection failed: " . $db_connection->connect_error);
        // }

        // $update_query = "UPDATE students SET score = ? WHERE StudentRegno = ?";
    
        // $stmt = $db_connection->prepare($update_query);
        
        // if ($stmt) 
        // {
        //     $stmt->bind_param("ii", $score, $studentRegID);
        //     if ($stmt->execute()) {
        //         echo "Score updated successfully!";
        //     } else {
        //         echo "Error storing score: " . $stmt->error;
        //     }
        //     $stmt->close();
        // } else {
        //     echo "Error preparing statement: " . $db_connection->error;
        // }

        // $db_connection->close();
    }else{
        echo "Session not set or username not found.";
    }

?>
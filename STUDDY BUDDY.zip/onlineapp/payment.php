<?php
session_start();
include('includes/config.php');
error_reporting(0);
if(strlen($_SESSION['login']) == 0) {
    header('location:index.php');
} 

$userid = $_SESSION['id'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>PHP Razorpay Payment Gateway Integration </title>
  <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script> 
<style>
  .card-product .img-wrap {
    border-radius: 3px 3px 0 0;
    overflow: hidden;
    position: relative;
    height: 220px;
    text-align: center;
  }
  .card-product .img-wrap img {
    max-height: 100%;
    max-width: 100%;
    object-fit: cover;
  }
  .card-product .info-wrap {
    overflow: hidden;
    padding: 15px;
    border-top: 1px solid #eee;
  }
  .card-product .bottom-wrap {
    padding: 15px;
    border-top: 1px solid #eee;
  }

  .label-rating { margin-right:10px;
    color: #333;
    display: inline-block;
    vertical-align: middle;
  }

  .card-product .price-old {
    color: #999;
  }
</style>
<body>
<?php include('includes/header.php');?>
    <!-- LOGO HEADER END-->
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');
}
?>

<div class="container">
<br><br><br>
<div class="row">

<div class="col-md-4">
<figure class="card card-product">
  <div class="img-wrap"><img src="https://wallpapercave.com/wp/wp7250222.jpg"></div>
  <figcaption class="info-wrap">
      <h4 class="title">Java</h4>
      <p class="desc">Java is an object-oriented programming language that produces software for multiple platforms. When a programmer writes a Java application.</p>
      <div class="rating-wrap">
        <div class="label-rating">132 reviews</div>
        <div class="label-rating">154 Subcriptions </div>
      </div> <!-- rating-wrap.// -->
  </figcaption>
  <div class="bottom-wrap">
    <a href="javascript:void(0)" class="btn btn-sm btn-primary float-right buy_now" data-img="//www.tutsmake.com/wp-content/uploads/2019/03/c05917807.png" data-amount="1000" data-id="1">Pay Now</a> 
    <div class="price-wrap h5">
      <span class="price-new">₹1000</span> <del class="price-old">₹1200</del>
    </div> <!-- price-wrap.// -->
  </div> <!-- bottom-wrap.// -->
</figure>
</div> <!-- col // -->

<div class="col-md-4">
<figure class="card card-product">
  <div class="img-wrap"><img src=https://th.bing.com/th/id/OIP.VZwY093Uo8Mr-uoeFNCAwwHaHa?pid=ImgDet&rs=1> </div>
  <figcaption class="info-wrap">
      <h4 class="title">Python</h4>
      <p class="desc">Python is a computer programming language often used to build websites and software, automate tasks, and conduct data analysis.</p>
      <div class="rating-wrap">
        <div class="label-rating">132 reviews</div>
        <div class="label-rating">144 Subcriptions </div>
      </div> <!-- rating-wrap.// -->
  </figcaption>
  <div class="bottom-wrap">
      <a href="javascript:void(0)" class="btn btn-sm btn-primary float-right buy_now" data-img="//www.tutsmake.com/wp-content/uploads/2019/03/vvjghg.png" data-amount="1280" data-id="2">Pay Now</a> 
      <div class="price-wrap h5">
        <span class="price-new">₹1280</span> <del class="price-old">₹1400</del>
      </div> <!-- price-wrap.// -->
  </div> <!-- bottom-wrap.// -->
</figure>
</div> <!-- col // -->

<div class="col-md-4">
<figure class="card card-product">
  <div class="img-wrap"><img src="//www.tutsmake.com/wp-content/uploads/2019/03/jhgjhgjg.jpg"></div>
  <figcaption class="info-wrap">
      <h4 class="title">C Programming</h4>
      <p class="desc">In this C Tutorial, you’ll learn all C programming basic to advanced concepts like variables, arrays, pointers, strings, loops, etc. </p>
      <div class="rating-wrap">
        <div class="label-rating">122 reviews</div>
        <div class="label-rating">194 Subcriptions </div>
      </div> <!-- rating-wrap.// -->
  </figcaption>
  <div class="bottom-wrap">
      <a href="javascript:void(0)" class="btn btn-sm btn-primary float-right buy_now" data-img="//www.tutsmake.com/wp-content/uploads/2019/03/jhgjhgjg.jpg" data-amount="1500" data-id="3">Pay Now</a> 
      <div class="price-wrap h5">
        <span class="price-new">₹1500</span> <del class="price-old">₹1980</del>
      </div> <!-- price-wrap.// -->
  </div> <!-- bottom-wrap.// -->
</figure>
</div> <!-- col // -->
</div> <!-- row.// -->

</div> 
<!--container.//-->

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>


<script src=""></script>
<script>
 
  $('body').on('click', '.buy_now', function(e){
    var prodimg = $(this).attr("data-img");
    var totalAmount = $(this).attr("data-amount");
    var product_id =  $(this).attr("data-id");
    var id = "<?php echo  $userid; ?>";
    var options = {
    "key": "rzp_test_wz5W3T8jAwKMLW", // secret key id
    "amount": (totalAmount*100), // 2000 paise = INR 20
    "name": "Tutsmake",
    "description": "Payment",
 
    "handler": function (response){
          $.ajax({
            url: 'payment-proccess.php',
            type: 'post',
            dataType: 'json',
            data: {
                id: id,razorpay_payment_id: response.razorpay_payment_id , totalAmount : totalAmount ,product_id : product_id,
            }, 
            success: function (msg) {
                // var data = JSON.parse(msg);
             
               window.location.href = 'payment-success.php?id='+ msg["rid"];
            }
        });
      
    },
 
    "theme": {
        "color": "#528FF0"
    }
  };
  var rzp1 = new Razorpay(options);
  rzp1.open();
  e.preventDefault();
  });
 
</script>
 <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>